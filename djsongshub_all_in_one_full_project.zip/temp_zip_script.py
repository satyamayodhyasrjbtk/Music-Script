
import os, zipfile

def zipdir(path, ziph):
    for root, dirs, files in os.walk(path):
        for file in files:
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, path)
            ziph.write(full_path, rel_path)

# 1. PHP Production Suite ZIP
php_suite_dir = "/app/applet/djsongshub_php_project"
php_zip_path = "/app/applet/public/djsongshub_php8_suite.zip"
root_php_zip = "/app/applet/djsongshub_php8_suite.zip"

with zipfile.ZipFile(php_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    zipdir(php_suite_dir, zipf)

with zipfile.ZipFile(root_php_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
    zipdir(php_suite_dir, zipf)

print(f"Created PHP Suite ZIP: {php_zip_path} ({os.path.getsize(php_zip_path)} bytes)")

# 2. Complete Project Source ZIP (React + PHP)
all_zip_path = "/app/applet/public/djsongshub_all_in_one_full_project.zip"
root_all_zip = "/app/applet/djsongshub_all_in_one_full_project.zip"

exclude_dirs = {'.git', 'node_modules', '.next', 'dist', '.cache'}
with zipfile.ZipFile(all_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk("/app/applet"):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for file in files:
            if file.endswith('.zip'):
                continue
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, "/app/applet")
            zipf.write(full_path, rel_path)

with zipfile.ZipFile(root_all_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk("/app/applet"):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for file in files:
            if file.endswith('.zip'):
                continue
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, "/app/applet")
            zipf.write(full_path, rel_path)

print(f"Created Full Project ZIP: {all_zip_path} ({os.path.getsize(all_zip_path)} bytes)")
